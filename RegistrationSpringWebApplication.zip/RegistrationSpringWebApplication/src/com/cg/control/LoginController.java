package com.cg.control;
import java.util.ArrayList;

import javax.validation.Valid;

import org.hibernate.mapping.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;
import com.cg.service.ILoginService;
@Controller
public class LoginController {
	@Autowired
	ILoginService loginService=null;
	public ILoginService getLoginService() {
		return loginService;}
	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;}
	//ModelAndView mdv=new ModelAndView("Login","username","Tharani");//viewName(with extension will be saved),objectName,objectValue
	//return mdv;
	/************************* To show LoginPage**********************************************/
	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login log=new Login();
		//log.setUserName("Enter your userName");
		model.addAttribute("loginCls", log);
		model.addAttribute("companyNameObject", "Capgemini");//viewObjectName,viewObjectValue
		return "Login";}
	/****************************Validate user,LoginPage************************************/
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="loginCls") @Valid Login log,BindingResult result,Model model) {
		if(result.hasErrors()) return "Login";else {
			if(loginService.isUserExist(log.getUserName())) {
		Login user=loginService.validateUser(log);
		if(user!=null) {
			model.addAttribute("sucessUserObj",log.getUserName());//This modelValue which is object value will be added to SuccessPage,since it is added before returning Success page as response
			return "Success";}else
		return "Failure";}}
		return "redirect:/ShowRegisterPage.obj";}
	/******************************************************************************************************/
	@ModelAttribute(value="cityListName1")
	public ArrayList<String> cityList(){
	ArrayList<String> cityListName=new ArrayList<>();
		cityListName.add("Chennai");
cityListName.add("Madurai");
cityListName.add("Dindigul");
cityListName.add("Coimbator");
return cityListName;}
	@ModelAttribute(value="skillListName1")
	public ArrayList<String> skillSetList(){
		ArrayList<String> skillSetList=new ArrayList<>();
		skillSetList.add("Java");
		skillSetList.add("Dot net");
		skillSetList.add("C");
		skillSetList.add("C++");
		skillSetList.add("R");
		skillSetList.add("Python");
		return skillSetList;}
	/********************************Show Registation page************************************************/
	@RequestMapping(value="/ShowRegisterPage")
	public String displayRegPage(Model model,@ModelAttribute(value="cityListName1")ArrayList<String> cityListName,@ModelAttribute(value="skillListName1")ArrayList<String> skillSetList) {
		RegisterDTO registerDTO=new RegisterDTO();
		model.addAttribute("register", registerDTO);// This value is given at the form as model Attribute name to refer before jsp gets loaded.
		model.addAttribute("cityList", cityListName);
		model.addAttribute("skillsetList",skillSetList);
		return "Register";}
	/******************************Registration and validation before getting data from User*************************************************************************/
	@RequestMapping(value="/InsertUser" ,method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="register") @Valid RegisterDTO reg,BindingResult result,Model model,@ModelAttribute(value="cityListName1")ArrayList<String> cityListName,@ModelAttribute(value="skillListName1")ArrayList<String> skillSetList) {
		if(result.hasErrors()) {
			model.addAttribute(cityListName);
			model.addAttribute("skillsetList",skillSetList);
			return "Register";}
		else {
			RegisterDTO registerDTO=loginService.insertUserDetails(reg);
			ArrayList<RegisterDTO > userList=loginService.getAllUserDetails();
			model.addAttribute("userListObject", userList);
	//	model.addAttribute("RegisterObject",registerDTO);
		return "ListAllUser";
	}
}
	/******************************DeleteUser****************************************************************/
	  @RequestMapping(value="/deleteUser",method=RequestMethod.GET)
	  public String deleteUser(@RequestParam(value="uid")String userName,Model model) {
		  boolean registerDTOFlag=loginService.deleteUser(userName);
		  if(registerDTOFlag) {
			ArrayList<RegisterDTO > userList=loginService.getAllUserDetails();
			model.addAttribute("userListObject", userList);
			model.addAttribute("MessageObject","Data Deleted");  
			return  "ListAllUser";
	  }
		return "Error";
	 }
	  
	  
	  


}
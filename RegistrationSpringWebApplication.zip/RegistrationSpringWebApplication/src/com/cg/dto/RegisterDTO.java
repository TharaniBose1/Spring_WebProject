package com.cg.dto;
import java.util.Arrays;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.cg.util.MyStringDateUtil;
@Entity
@Table(name="cg_UserDetails")
public class RegisterDTO {
	@Id
	@Column(name="user_name",length=25)
	private String userName;
	@Column(name="first_user",length=20)
	private String firstName;
	@Column(name="last_user",length=20)
	private String lastName;
	@Transient  //this annotation which is not included in this table,but will be inserted in login
	private String passWord;
	@Transient
	private String confirmPassWord;
	@Column(name="user_email",length=25)
	private String emailId;
	@Transient
	private String[] skillSet;
@Column(name="user_skills",length=100)
	private String skillSetStr;
@Column(name="user_gender",length=1)
	private char gender;
	@Column(name="user_city",length=20)
	private String city;
	public RegisterDTO() {}
public String getSkillSetStr() {
		return skillSetStr;
	}
	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}
	@NotEmpty(message="Please Select atleast one")
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
		String skills=MyStringDateUtil.fromArrayToCommaSeparatedString(skillSet);
		setSkillSetStr(skills);
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	//	@NotEmpty(message="Please Enter FirstName of Only Alphabets")
	@Pattern(regexp="[A-Z][a-z]*",message="Please Enter FirstName of Only Alphabets")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;}
	@NotEmpty(message="Please Enter LastName")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@NotEmpty(message="Please Enter Password")
	//@Pattern(regexp="[A-Z][a-z][0-9]*",message="Please Enter FirstName of Only Alphabets as Passwords")
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	@NotEmpty(message="Please Re-Enter Password")
	//@Pattern(regexp="[A-Z][a-z][0-9]*",message="Please  Re-Enter Password")
	public String getConfirmPassWord() {
		return confirmPassWord;
	}
	public void setConfirmPassWord(String confirmPassWord) {
		this.confirmPassWord = confirmPassWord;
	}
	@NotEmpty(message="Enter Email id")
	@Email(message="Enter Valid Email id ")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}@NotEmpty(message="Please Select City")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "RegisterDTO [firstName=" + firstName + ", lastName=" + lastName + ", passWord=" + passWord
				+ ", confirmPassWord=" + confirmPassWord + ", emailId=" + emailId + ", skillSet="
				+ Arrays.toString(skillSet) + ", gender=" + gender + ", city=" + city + "]";
	}
}

package com.cg.dao;
import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;
public interface ILoginDAO {
public boolean isUserExist(String userName );
public Login validateUser(Login login);
public RegisterDTO insertUserDetails(RegisterDTO userDetails);
public ArrayList<RegisterDTO> getAllUserDetails();
public boolean deleteUser(String userName);
}

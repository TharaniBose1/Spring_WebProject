package com.cg.dto;
public class DeleteTrainee {

}

package com.cg.control;
import java.util.ArrayList;
import javax.validation.Valid;
import org.hibernate.mapping.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.dto.Login;
import com.cg.dto.Trainee;
import com.cg.dto.Trainee;
import com.cg.service.ILoginService;
@Controller
public class AdminController {
	@Autowired
	ILoginService loginService=null;
	public ILoginService getLoginService() {
		return loginService;}
	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;}
	//ModelAndView mdv=new ModelAndView("Login","username","Tharani");//viewName(with extension will be saved),objectName,objectValue
	//return mdv;	
	/****************************Validate user,LoginPage************************************/
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String validateDetails(@ModelAttribute(value="loginClass") @Valid Login log,BindingResult result	,Model model) {
		if(result.hasErrors()) return "Login";else {
			if(loginService.isUserExist(log.getUserName())) {
				Login user=loginService.validateUser(log);
				if(user!=null) {
					model.addAttribute("sucessUserObj",log.getUserName());//This modelValue which is object value will be added to SuccessPage,since it is added before returning Success page as response
					return "NextPage1";}else
						return "Failure";}}
		return "Message";}
	/******************************************************************************************************/
	@ModelAttribute(value="trainingDomainList")
	public ArrayList<String> skillSetList(){
		ArrayList<String> trainingDomainList=new ArrayList<>();
		trainingDomainList.add("Java");
		trainingDomainList.add("Dot net");
		trainingDomainList.add("C");
		trainingDomainList.add("C++");
		trainingDomainList.add("R");
		trainingDomainList.add("Python");
		return trainingDomainList;}
	/********************************Show Registation page************************************************//*
	@RequestMapping(value="/ShowRegisterPage")
	public String displayRegPage(Model model,@ModelAttribute(value="trainingDomainList")ArrayList<String> trainingDomainList) {
		Insert registerObj=new Insert();
		model.addAttribute("register", registerObj);// This value is given at the form as model Attribute name to refer before jsp gets loaded.
		model.addAttribute("trainingDomainList",trainingDomainList);
		return "Register";}*/
	
	/****************************************Display Insertion Form for Trainee *******************************************/
	@RequestMapping(value="/ShowInsertionPage")
	public String displayInsertionPage(Model model,@ModelAttribute(value="trainingDomainList")ArrayList<String> trainingDomainList) {{
			model.addAttribute("insert",new Trainee());// This value is given at the form as model Attribute name to refer before jsp gets loaded.
			model.addAttribute("trainingDomainList",trainingDomainList );
			return "Insert";}}
	/******************************Insertion of data from User and Displaying on Page*************************************************************************/
	@RequestMapping(value="/InsertUser" ,method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="insert")Trainee ins,BindingResult result,Model model,@ModelAttribute(value="trainingDomainList")ArrayList<String> trainingDomainList) {
		if(result.hasErrors()) {
			//model.addAttribute(cityListName);
			model.addAttribute("trainingDomainList",trainingDomainList);
			return "Insert";}
		else {
			loginService.insertUserDetails(ins);
			ArrayList<Trainee> traineeList=loginService.getAllUserDetails();
			//model.addAttribute("Insert",insertion);
			model.addAttribute("insertedListObject", traineeList);
			//	model.addAttribute("RegisterObject",registerDTO);
			return "ListAllUser";
		}}
/**********************************************Delete Entry Page Detail*****************************************************************************************/	
@RequestMapping(value="/ShowDeletePage")
	public String displayTraineeDetails(Model model) {
	model.addAttribute("delete", new Trainee());
	return "Delete";
}
/****************************************************Delete the record and delete the message to User*********************************/
@RequestMapping(value="/DeleteUser")
public String deleteTraineeDetails(@ ModelAttribute(value="delete") Trainee trainee,Model model) {
	loginService.getTraineeDetail(14);
	loginService.deleteUser(trainee.getTrainee_id());
	return "DeleteSuccessPage";
	
}


}
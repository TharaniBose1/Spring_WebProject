package com.cg.service;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.ILoginDAO;
import com.cg.dto.Trainee;
import com.cg.dto.Login;
@Service("loginService")
public class ILoginServiceImpl implements ILoginService {
	@Autowired
	ILoginDAO loginDAO=null;
	public ILoginDAO getLoginDAO() {
		return loginDAO;
	}
	public void setLoginDAO(ILoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}
	@Override
	public boolean isUserExist(String userName) {
		return /* loginDAO.isUserExist(userName)*/true;
	}
	@Override
	public Login validateUser(Login login) {
	if(login.getUserName().equalsIgnoreCase("admin"/*loginDAO.validateUser(login).getUserName()*/)&& login.getPassword().equalsIgnoreCase("admin"/*loginDAO.validateUser(login).getPassword()*/))
			return login;
		return null;
	}
	@Override
	public Trainee insertUserDetails(Trainee userDetails) {	
		return loginDAO.insertUserDetails(userDetails);
	}
	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		
		return loginDAO.getAllUserDetails();
	}
	@Override
	public boolean deleteUser(int trainee_id) {
		
		return loginDAO.deleteUser(trainee_id);
	}
	@Override
	public Trainee getTraineeDetail(int id) {
		System.out.println(loginDAO.getTraineeDetail(id));
		return loginDAO.getTraineeDetail(id);
	}
	
}

package comc.cg.beans;
import org.springframework.asm.SpringAsmInfo;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@ComponentScan(basePackages="comc.cg.beans")
public class TestXmlAnnotationEmployeeDemo {
	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(TestXmlAnnotationEmployeeDemo.class, args);
		Employee employee1=(Employee) context.getBean("employee1");
		System.out.println(employee1);
		System.out.println("--------------------------------");
		
	}

}

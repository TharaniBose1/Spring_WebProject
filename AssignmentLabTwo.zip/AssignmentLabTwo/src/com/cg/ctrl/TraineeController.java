package com.cg.ctrl;

public class TraineeController {

}

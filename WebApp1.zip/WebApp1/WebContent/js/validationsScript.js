function validateRegistrationForm(){
	if(registerForm.firstName.value==""){
	alert("Enter firstName!Please");
	return false;
	}
	else if(registerForm.lastName.value==""){
		alert("Enter lastName!Please");
		return false;
		}
	else if(registerForm.emailID.value==""){
		alert("Enter Email Id!Please");
		return false;
		}
	else if(registerForm.department.value==""){
			alert("Enter Department!Please");
			return false;
		}
	else if(registerForm.designation.value==""){
			alert("Enter Designation!Please");
			return false;
		}
	else if(registerForm.panNumber.value==""){
		alert("Enter PAN Number!Please");
		return false;
	}
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
			alert("Enter your Yearly Investement!Please");
			return false;
		}
	else if(registerForm.basicSalary.value==""){
			alert("Enter your Basic Salary!Please");
			return false;
		}
	else if(registerForm.bankName.value==""){
			alert("Enter Bank Name!Please");
			return false;
		}
	else if(registerForm.accountNumber.value==""){
			alert("Enter Account Number!Please");
			return false;
		}
	
}
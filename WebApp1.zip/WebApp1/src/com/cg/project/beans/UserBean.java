package com.cg.project.beans;
import java.util.List;
public class UserBean {
private int associateId;
private String password,firstName,lastName,emailID,mobileNumber,gender;
private List<String> communications;
public UserBean(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}
public UserBean(String password, String firstName, String lastName, String emailID, String mobileNumber, String gender,
		List<String> communications) {
	super();
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailID = emailID;
	this.mobileNumber = mobileNumber;
	this.gender = gender;
	this.communications = communications;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmailID() {
	return emailID;
}
public void setEmailId(String emailID) {
	this.emailID = emailID;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public List<String> getCommunications() {
	return communications;
}
public void setCommunications(List<String> communications) {
	this.communications = communications;
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}

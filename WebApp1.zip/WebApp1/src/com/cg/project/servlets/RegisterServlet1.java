package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/register1")
public class RegisterServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterServlet1() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
String firstName=request.getParameter("firstName");
String lastName=request.getParameter("lastName");
String emailID=request.getParameter("emailID");
String department=request.getParameter("department");
String designation=request.getParameter("designation");
String panNumber=request.getParameter("panNumber");
int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
String bankName=request.getParameter("bankName");
int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
out.println("<html><body>");
out.println("<font color:black size:12px> Firstname:"+firstName+"</font>"+"<br>");
out.println("<font color:black size:12px> Lastname:"+lastName+"</font>"+"<br>");
out.println("<font color:black size:12px> EmailId:"+emailID+"</font>"+"<br>");
out.println("<font color:black size:12px> Department:"+department+"</font>"+"<br>");
out.println("<font color:black size:12px> Designation:"+designation+"</font>"+"<br>");
out.println("<font color:black size:12px> PanCard Number:"+panNumber+"</font>"+"<br>");
out.println("<font color:black size:12px> Yearly InVestmentUnder80C:"+yearlyInvestmentUnder80C+"</font>"+"\n");
out.println("<font color:black size:12px> Basic salary:"+basicSalary+"</font>"+"<br>");
out.println("<font color:black size:12px> Bankname:"+bankName+"</font>"+"<br>");
out.println("<font color:black size:12px> Account:"+accountNumber+"</font>"+"<br>");
out.println("</body></html>");

	}

}

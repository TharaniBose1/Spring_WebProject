package com.cg.project.servlets;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;
@WebServlet("/register2")
public class RegisterServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterServlet2() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String firstName=request.getParameter("firstName");
String lastName=request.getParameter("lastName");
String password=request.getParameter("password");
	String mobileNumber=request.getParameter("mobileNumber");
String gender=request.getParameter("gender");
String emailID=request.getParameter("emailID");
String [] communication=request.getParameterValues("communication");
List<String> communications=Arrays.asList(communication);
UserBean bean=new UserBean(password, firstName, lastName, emailID, mobileNumber, gender, communications);
request.setAttribute("bean", bean);
request.getRequestDispatcher("registrationSucessPage.jsp").forward(request, response);		
}}

package com.cg.ctrl;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.dto.HotelDetails;
import com.cg.service.BookingService;
@Controller
public class BookingController {
	@Autowired
	BookingService bookingService=null;
	public BookingService getBookingService() {
		return bookingService;
	}
	public void setBookingService(BookingService bookingService) {
		this.bookingService = bookingService;
	}
	@RequestMapping(value="/HotelDetails",method=RequestMethod.GET)
public String displayHotelDetails(Model model,@ModelAttribute(value="hotel")HotelDetails hotelObj) {
		model.addAttribute("hotelDetail",bookingService.getAllDetails());
	return "HotelBooking" ;}
/*	@RequestMapping(value="/HotelBookingView",method=RequestMethod.GET)
	public String displayHotelBookingView(Model model,@ModelAttribute(value="hotel")HotelDetails hotelObj) {
		model.addAttribute("Display",hotelObj);
		return "HotelBookingEntry";
		
	}*/
	/*@RequestMapping(value="/HotelBooking",method=RequestMethod.GET)
	public String displayHotelBooking(Model model,@ModelAttribute(value="hotel")HotelDetails hotelObj) {
			ArrayList<HotelDetails> hotelList=bookingService.getAllDetails();
			model.addAttribute("Display",hotelObj);
			model.addAttribute("hotelList", hotelList);
		return "HotelBooking" ;}*/
}

package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.HotelDetails;

public interface BookingService {
	public ArrayList<HotelDetails>getAllDetails();
}

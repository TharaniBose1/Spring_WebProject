package comc.cg.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("user1")
public class User {
	@Value("${username}")
private String userName;
	@Value("${password}")
	private String userPassword;
public User() {}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
@Override
public String toString() {
	return "User Details[userName=" + userName + ", userPassWord=" + userPassword + "]";
}
}

package comc.cg.beans;
public interface IGreet {
public String greetMe();
}

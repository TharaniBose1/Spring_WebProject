package comc.cg.beans;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("object2")
public class BirthdayGreeting implements IGreet,BeanNameAware,BeanFactoryAware,DisposableBean,InitializingBean {
	@Value("Tharani")
String firstName;
	public BirthdayGreeting() {
		System.out.println("In BirthdayGreeeting"+"Constructor");
	}
	public String getFirstName() {
	return firstName;
}
public BirthdayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}
public void setFirstName(String firstName) {
	this.firstName = firstName;
	System.out.println("---->setFirstName is called for birthday wish");
	System.out.println("Inside parameterixzed constr");
}
	@Override
	public String greetMe() {
		
		return "Happy Birthday  "+firstName;
	}
	@Override
	public void setBeanName(String beanName) {
		
		System.out.println(".........In setBean() called..."+beanName);
	}
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("------In setBeanFactory()------"+beanFactory.toString());
		
	}
	//intializzing interface
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("-----This is called after firstName set value");
		
	}
	//disposal interface
	@Override
	public void destroy() throws Exception {
		System.out.println("Destroy is called.......");
		
	}
	public void cgInit() {
		System.out.println("This is custom CG Init");
	}
	public void cgDestroy() {
		System.out.println("This is custom CG Destory");
	}
}

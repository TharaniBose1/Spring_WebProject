package com.cg.dao;
import java.util.ArrayList;
import com.cg.dto.Trainee;
import com.cg.dto.Login;;
public interface ILoginDAO {
public Login validateUser(Login login);
public Trainee insertUserDetails(Trainee userDetails);
public ArrayList<Trainee> getAllUserDetails();
public Trainee getTraineeDetail(int id);
public boolean deleteUser(int id);
public Trainee modifyTraineeDetails(int id, String name, String domain, String location);
public Trainee modifyTraineeDetails(Trainee trainee);
}

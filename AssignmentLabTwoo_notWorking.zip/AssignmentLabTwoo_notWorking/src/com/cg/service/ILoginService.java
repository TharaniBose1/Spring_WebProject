package com.cg.service;
import java.util.ArrayList;
import com.cg.dto.Trainee;
import com.cg.dto.Login;
public interface ILoginService {
	public boolean isUserExist(String userName );
	public Login validateUser(Login login);
	public Trainee insertUserDetails(Trainee userDetails);
	public ArrayList<Trainee> getAllUserDetails();
	public boolean deleteUser(int trainee_id);
	public Trainee getTraineeDetail(int id);
    public Trainee modifyTraineeDetails(int id, String name, String domain, String location);
	public Trainee modifyTraineeDetails(Trainee trainee);
}

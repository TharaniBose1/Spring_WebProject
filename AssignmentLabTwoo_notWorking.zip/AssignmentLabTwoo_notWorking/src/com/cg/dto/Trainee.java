package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="cg_TraineeDetails")
public class Trainee {
@Id
private int trainee_id;
private String trainee_name;
private String trainee_location;
private String training_domain;
public Trainee() {}
public int getTrainee_id() {
	return trainee_id;}
public void setTrainee_id(int trainee_id) {
	this.trainee_id = trainee_id;}
public String getTrainee_name() {
	return trainee_name;
}
public void setTrainee_name(String trainee_name) {
	this.trainee_name = trainee_name;
}
public String getTrainee_location() {
	return trainee_location;
}

public void setTrainee_location(String trainee_location) {
	this.trainee_location = trainee_location;
}

public String getTraining_domain() {
	return training_domain;
}
public void setTraining_domain(String training_domain) {
	this.training_domain = training_domain;
}
@Override
public String toString() {
	return "Trainee [trainee_id=" + trainee_id + ", trainee_name=" + trainee_name + ", trainee_location="
			+ trainee_location + ", training_domain=" + training_domain + "]";
}



}

 package com.cg.dao;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Trainee;
import com.cg.dto.Login;
@Repository("loginDAO")
@Transactional
public class ILoginDAOImpl implements ILoginDAO{
	@PersistenceContext
	EntityManager entityManger=null;
	public EntityManager getEntityManger() {
		return entityManger;
	}
	public void setEntityManger(EntityManager entityManger) {
		this.entityManger = entityManger;
	}
	@Override
	public boolean isUserExist(String userName) {
		Login user=entityManger.find(Login.class,userName);
		if(user!=null)return true;
		return false;}
	@Override
	public Login validateUser(Login login) {	
		Login user=entityManger.find(Login.class,login.getUserName());
		return user;}
	@Override
	public Trainee insertUserDetails(Trainee traineeDetails) {
		//Insert insertObject=new Insert();
		 
			/*StringBuffer str=new StringBuffer();
			for (String tempStr:userDetails.getSkillSet() )
				str.append(tempStr+",");
				//str+=tempStr+",";			
			userDetails.setSkillSetStr(str.toString());*/
		System.out.println("Hey This is trainee'S id :"+traineeDetails.getTrainee_id());
		entityManger.persist(traineeDetails);
		entityManger.flush();
	//	Trainee registeredUser=entityManger.find(Trainee.class, traineeDetails.getTrainee_id());
		return traineeDetails;
	}
	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		String query="Select register From Trainee register";
		TypedQuery typedQuery=entityManger.createQuery(query,Trainee.class);
		ArrayList<Trainee> updatedList=(ArrayList<Trainee>) typedQuery.getResultList();
		return updatedList;
	}
	@Override
	public boolean deleteUser(int id) {
		Trainee traineeFlag=entityManger.find(Trainee.class,id);
		System.out.println("Id   :"+traineeFlag);
		entityManger.remove(traineeFlag);
		entityManger.flush();
		return true;
	}
	@Override
	public Trainee getTraineeDetail(int id) {
		
		return entityManger.find(Trainee.class, id);
	} 
	@Override
	public Trainee modifyTraineeDetails(int id, String name, String domain, String location) {
		Trainee trainee=this.getTraineeDetail(id);
		trainee.setTrainee_id(id);
		trainee.setTrainee_name(name);
		trainee.setTraining_domain(domain);
		trainee.setTrainee_location(location);
		entityManger.merge(trainee);
		entityManger.flush();
		return trainee;
	}
	@Override
	public Trainee modifyTraineeDetails(Trainee trainee) {
		entityManger.merge(trainee);
		return trainee;
	}	
}

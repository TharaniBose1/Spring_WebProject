package com.cg.ctrl;
import java.io.IOException;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.log.SysoLogger;
@Controller
public class BankingController {
	@Autowired
	BankingServices bankingService=null;
	public BankingServices getBankingService() {
		return bankingService;
	}
	public void setBankingService(BankingServices bankingService) {
		this.bankingService = bankingService;
	}
	@RequestMapping(value="/ShowAccountCreationPage.obj")
public  String displayCreateAccountPage(Model model,@ModelAttribute(value="typeOfAccount") ArrayList<String> typeOfAccount) {
		Account account=new Account();
	model.addAttribute("createAccount", account);
		model.addAttribute("welcome", "Welcome for ABC Bank");
	model.addAttribute("typeOfAccount",typeOfAccount);
	return"CreateAccountPage";
}
	@ModelAttribute(value="typeOfAccount")
	public ArrayList<String> typeOfAccountList(){
		ArrayList<String> typeOfAccount=new ArrayList<>();
		typeOfAccount.add("Salary");
		typeOfAccount.add("Savings");
		typeOfAccount.add("Current");
		return typeOfAccount;
	}
	@RequestMapping(value="/ShowAccountAndPinNo.obj")
	public String displayAccountNoPinNo(Model model,@ModelAttribute(value="createAccount")Account account) {
		try {
			model.addAttribute("account", bankingService.openAccount(account.getAccountType(),account.getAccountBalance()));}
		catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			model.addAttribute("notCreated","Sorry,Account Can be created!");}
		return "CreatedAccountPage";
	}
	@RequestMapping(value="/ShowWithDrawPage.obj")
	public String displayWithdraw(Model model,@ModelAttribute(value="Accountwithdraw")Account account) {
		model.addAttribute("withdraw", new Account());
		return "WithDrawPage";
	}
	@RequestMapping(value="/Withdraw.obj",method=RequestMethod.POST)
	public String doWithdraw(Model model,@ModelAttribute(value="Accountwithdraw")Account account,@RequestParam("amount")int amount) {
		try {
			model.addAttribute("withdraw",bankingService.withdrawAmount(account.getAccountNo(),amount,account.getPinNumber()));
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException | IOException | DocumentException e) {
			         model.addAttribute("notWithdrawn","Insufficient Balance or Wrong PinNumber.Please contact Manager");	}
		return "WithDrawedPage";
	}
	@RequestMapping(value="/ShowDepositPage.obj")
	public String displayDeposit(Model model,@ModelAttribute(value="AccountDeposit")Account account) {
		return "DepositPage";
	}
	@RequestMapping(value="/Deposit.obj",method=RequestMethod.POST)
	public String deposit(Model model,@ModelAttribute(value="AccountDeposit")Account account,@RequestParam(value="amount")int amount) {
		try {
			model.addAttribute("deposit",bankingService.depositAmount(account.getAccountNo(), amount));
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException | IOException
				| DocumentException e) {
			e.printStackTrace();
		}
		return "DepositedPage";}
	@RequestMapping(value="/ShowFundTransferPage.obj")
	public String  displayFundTransfer(Model model,@ModelAttribute(value="FundTransfer")Account account) {
		return "FundTransferPage";	}
	@RequestMapping(value="/FundTransfer.obj",method=RequestMethod.POST)
	public String fundTransferred(Model model,@ModelAttribute(value="FundTransfer")Account account,@RequestParam(value="amount")int amount,@RequestParam(value="accountNoTo")int accountNoTo) {
		try {
			boolean flag=bankingService.fundTransfer(accountNoTo, account.getAccountNo(), amount, account.getPinNumber());
			if(flag)model.addAttribute("fundTransfer","Funds got Transfered!");
			else model.addAttribute("fundTransfer","Sorry,Funds cannot be transfered!");
			model.addAttribute("currentBalance",bankingService.getAccountDetails(account.getAccountNo()).getAccountBalance());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException | IOException | DocumentException e) {
			e.printStackTrace();
		}
		return "FundTransferredPage";
	}
	@RequestMapping(value="/ShowAccountsPage.obj")
	public String displayAccountDetails(Model model,@ModelAttribute(value="accountDetails")Account account) {
		return "AccountIndexPage";
	}
	@RequestMapping(value="/AccountDetails.obj",method=RequestMethod.POST)
	public String displayAccountDetail(Model model,@ModelAttribute(value="accountDetails")Account account) {
		try {
			model.addAttribute("accountDetails",bankingService.getAccountDetails(account.getAccountNo()));
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException | IOException
				| DocumentException e) {
			e.printStackTrace();
		}
		return "AccountDetails";
	}
	@RequestMapping(value="/ShowAllTrasactionsPage.obj")
	public String displayTransaction(Model model,@ModelAttribute(value="accountDetails")Account account) {
		return "TransactionIndexPage";
	}
	@RequestMapping(value="/TransactionDetails.obj",method=RequestMethod.POST)
	public String displayAccountAllTrasanctions(Model model,@ModelAttribute(value="accountDetails")Account account) {
			try {
				model.addAttribute("transactionDetail",bankingService.getAccountAllTransaction(account.getAccountNo()));
			} catch (BankingServicesDownException | AccountNotFoundException e) {
				e.printStackTrace();
			}
		
		return "TranscationDetail";
	}
}

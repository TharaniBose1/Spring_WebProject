package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cg.banking.beans.Transaction;
@Repository("transcationDAO")
@Transactional
public class TransactionDAOImpl implements TransactionDAO{
	@PersistenceContext
	private EntityManager  entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public Transaction save(Transaction transaction) {
		entityManager.persist(transaction);
    		return transaction;
	}
	@Override
	public boolean update(Transaction transaction) {
		
		entityManager.merge(transaction);
		
		return true;
	}
	@Override
	public Transaction findOne(int transactionId) {
		
		return entityManager.find(Transaction.class, transactionId);
	}
	@Override
	public List<Transaction> findAll(long accountNumber) {
		String query="Select trans From Transaction_Entity trans where ACCOUNT_ACCOUNTNO="+accountNumber;
		TypedQuery typedQuery=entityManager.createQuery(query, Transaction.class);
		ArrayList<Transaction> updatedList=(ArrayList<Transaction>) typedQuery.getResultList();
		return updatedList;
	}
	

}

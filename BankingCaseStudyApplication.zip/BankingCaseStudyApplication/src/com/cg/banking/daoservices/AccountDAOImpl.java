package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Account;
@Repository("accountDAO")
@Transactional
public class AccountDAOImpl implements AccountDAO {
	@PersistenceContext
private EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public Account save(Account account) {
		entityManager.persist(account);
        entityManager.flush();
		return account;
	}
	@Override
	public boolean update(Account account) {

		entityManager.merge(account);
       
		return true;
	}
	@Override
	public Account findOne(long accountNo) {
		return entityManager.find(Account.class,accountNo);
	}
	@Override
	public List<Account> findAll() {
		String query="Select register From Account_Bank register";
		TypedQuery typedQuery=entityManager.createQuery(query,Account.class);
		ArrayList<Account> updatedList=(ArrayList<Account>) typedQuery.getResultList();
		return updatedList;
	}
	

}

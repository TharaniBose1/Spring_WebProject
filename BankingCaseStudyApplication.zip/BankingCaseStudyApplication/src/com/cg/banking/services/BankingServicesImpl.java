package com.cg.banking.services;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@Service
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO accountDAO=null;
	@Autowired
	private TransactionDAO transcationDAO=null;
	public AccountDAO getAccountDAO() {
		return accountDAO;
	}
	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}
	public TransactionDAO getTranscationDAO() {
		return transcationDAO;
	}
	public void setTranscationDAO(TransactionDAO transcationDAO) {
		this.transcationDAO = transcationDAO;
	}
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account.setAccountType(accountType);	
		account.setStatus("Active");
		account.setPinNumber(Integer.parseInt( String.format("%4d", new Random().nextInt(10000))));
		accountDAO.save(account);
		Transaction transaction=new Transaction(initBalance,account);
		transaction.setTransactionType("Deposit");
		transcationDAO.save(transaction);
		return account;}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, FileNotFoundException,IOException, DocumentException {
		Account account= this.getAccountDetails(accountNo);
		//this.accountStatus(accountNo);
		if(account==null)throw new AccountNotFoundException("Account does not exist!");
		account.setAccountBalance(account.getAccountBalance()+amount);
		accountDAO.update(account);
		Transaction transaction=new Transaction(amount,account);
		transaction.setTransactionType("Deposit");
		transcationDAO.save(transaction);
		System.out.println("Updated in DB");

		return account.getAccountBalance();}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, FileNotFoundException, IOException, DocumentException {
		Account account=this.getAccountDetails(accountNo);
		if(account.getPinNumber()==pinNumber )	
			if(account.getAccountBalance()<500) throw new InsufficientAmountException("Insufficient Amount");
			else account.setAccountBalance(account.getAccountBalance()-amount);		
		else throw new InvalidPinNumberException("Invalid Pin Number");
		accountDAO.update(account);
		Transaction transaction=new Transaction(amount,account);
		transaction.setTransactionType("WithDraw");
		transcationDAO.save(transaction);
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, FileNotFoundException, IOException, DocumentException {
		Account accountFrom=this.getAccountDetails(accountNoFrom);
		Account accountTo=this.getAccountDetails(accountNoTo);
		Transaction transaction1=new Transaction(transferAmount, accountFrom);
		Transaction transaction2=new Transaction(transferAmount, accountTo);
		transaction1.setTransactionType("Online Transfer");
		transaction2.setTransactionType("Online Transfer");
		//if(this.accountStatus(accountNoTo)=="Active" && (this.accountStatus(accountNoFrom)=="Active"));
		//if(accountDAO.findOne(accountNoTo) ==null &&accountDAO.findOne(accountNoFrom) ==null) throw new AccountNotFoundException("Account doesnot Exist!");
		if(accountFrom.getAccountBalance()<500)throw new InsufficientAmountException("Amount is insufficient");
		if(pinNumber!=accountFrom.getPinNumber())throw new InvalidPinNumberException("Entered is Invalid PinNumber!"); 
		accountFrom.setAccountBalance(this.withdrawAmount(accountNoFrom, transferAmount, accountFrom.getPinNumber()));
		accountTo.setAccountBalance(this.depositAmount(accountNoTo, transferAmount));
		System.out.println("BALANCE    HELLO1   "+accountFrom.getAccountBalance());
		System.out.println("BALANCE    HELLO2    "+accountTo.getAccountBalance());
		accountDAO.update(accountFrom);
		accountDAO.update(accountTo);
		transcationDAO.save(transaction1);
		transcationDAO.save(transaction2);
		return true;}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, FileNotFoundException, IOException, DocumentException {
		Account account=new Account(accountNo);
		account=accountDAO.findOne(accountNo);
		if(this.accountStatus(accountNo)=="Active");
		if(account==null)throw new AccountNotFoundException("Account doesnot Exist!");
		return account;
	}
	@Override
	public String accountStatus(long accountNo)throws AccountBlockedException,BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=accountDAO.findOne(accountNo);
		if(account.getStatus()==null || account.getStatus()=="blocked")throw new AccountBlockedException("Account is blocked or inactive or doesnot exist.Please contact the consern Manager"+account.getAccountNo());
		else return " Active";
	}
	@Override
    public void pdfGenerator(long accountNo) throws FileNotFoundException, DocumentException, BankingServicesDownException, AccountNotFoundException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:\\Users\\ADM-IG-HWDLAB2E\\Transactions.pdf"));
        document.open();
        document.add(new Paragraph("Transactions: "));
        com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
        document.add(orderedList);
        for(Transaction t: new ArrayList<>(getAccountAllTransaction(accountNo))) {
            orderedList.add(t.toString());
        }
        document.add(orderedList);
        document.close();
        writer.close();
        Transaction transaction=new Transaction();
    	transaction.setTransactionType("Mini Statement!!Checking");
    	transcationDAO.save(transaction);
    }
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return  transcationDAO.findAll(accountNo);
	}
}
	
		          

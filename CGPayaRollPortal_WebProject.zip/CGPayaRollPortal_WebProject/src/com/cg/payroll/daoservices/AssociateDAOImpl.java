package com.cg.payroll.daoservices;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class AssociateDAOImpl implements AssociateDAO {
private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Associate save(Associate associate) {
	EntityManager entityManger=entityManagerFactory.createEntityManager();
	entityManger.getTransaction().begin();
	entityManger.persist(associate);
	entityManger.getTransaction().commit();
	entityManger.close();
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		EntityManager entityManger=entityManagerFactory.createEntityManager();
		entityManger.getTransaction().begin();
		entityManger.merge(associate);
		entityManger.getTransaction().commit();
		entityManger.close();
		return true;
	}
	@Override
	public Associate findOne(int associateId) throws AssociateDetailsNotFoundException {
		return entityManagerFactory.createEntityManager().find(Associate.class, associateId);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Associate> findAll() {
		EntityManager entityManger=entityManagerFactory.createEntityManager();
		return 	entityManger.createQuery("from Associate refObj").getResultList();
	}
	@Override
	public boolean delete(int associateId) throws AssociateDetailsNotFoundException {
		EntityManager entityManger=entityManagerFactory.createEntityManager();
		entityManger.getTransaction().begin();
		//Query query=entityManger.createQuery("delete Associate  where associateId ==associateId from Associate refObj");
		//query.executeUpdate();
		entityManger.remove(entityManger.merge(this.findOne(associateId)));
		entityManger.getTransaction().commit();
		entityManger.close();
		return true;
	}

		
}

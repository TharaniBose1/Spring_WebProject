package com.cg.payroll.servlets;

import java.io.IOException;

import javax.annotation.ManagedBean;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/controller2")

public class CalculateSalary extends HttpServlet {
	int associateID1;

	public int getAssociateID1() {
		return associateID1;
	}

	public void setAssociateID1(int associateID1) {
		this.associateID1 = associateID1;
	}

	PayrollServices payrollServices = new PayrollServicesImpl();
	private static final long serialVersionUID = 1L;

	public CalculateSalary() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int associateID2 = Integer.parseInt(request.getParameter("associateID"));
		RequestDispatcher dispatcher = null;
		try {
			Associate associate = payrollServices.getAssociateDetails(associateID2);
			int associateSalary = payrollServices.calculateNetSalary(associate.getAssociateID());
			associate.getSalary().setNetSalary(associateSalary);
			request.setAttribute("associate1", associate);
			dispatcher = request.getRequestDispatcher("calculateEntrySuccessPage.jsp");
			dispatcher.forward(request, response);
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}

	}

}

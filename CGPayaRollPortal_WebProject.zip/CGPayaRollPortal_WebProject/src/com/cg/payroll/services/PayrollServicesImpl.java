package com.cg.payroll.services;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl  implements PayrollServices {
		private AssociateDAO  associateDAO;
		public PayrollServicesImpl() {
			associateDAO=new AssociateDAOImpl();
		}
		public PayrollServicesImpl(AssociateDAO associateDAO) {
			super();
			this.associateDAO = associateDAO;
		}
		@Override
		public int acceptAssociateDetails(Associate associate) throws InvalidEmailException, AssociateDetailsNotFoundException {
			   //Associate associate=new Associate(yearlyInvestmentUnder80C,firstName,  lastName, department, designation, pancard, emailId, salary, bankDetails);
		 /*  String emailPattern="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
			Pattern p1= Pattern.compile(emailPattern);
			String str=associate.getEmailId().toString();
			Matcher m = p1.matcher(str);
			if (!m.find())  throw new InvalidEmailException("Please Enter validate Email ID");*/
			associate=associateDAO.save(associate);
			//this.calculateNetSalary(associate.getAssociateID());
			return associate.getAssociateID();
		}
		@Override
		public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {
			Associate associate =this.getAssociateDetails(associateID); 
			associate.getSalary().setHra(associate.getSalary().getBasicSalary()*2/5);
			associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*3/10);
			associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()/5);
			associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()/5);	
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getHra()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance());
			int investment=associate.getSalary().getCompanyPf()*12+associate.getSalary().getEpf()*12+associate.getYearlyInvestmentUnder80C();
			System.out.println(associate.getSalary().getGrossSalary());
			System.out.println("Investment:  "+investment);
			int taxableAmount;
			if(investment<=180000)
				taxableAmount=associate.getSalary().getGrossSalary()*12-investment;
			else
				taxableAmount=associate.getSalary().getGrossSalary()*12+(investment-180000);
			System.out.println(associateID);
			System.out.println("Taxaable Amount" +taxableAmount);
			if(taxableAmount>250000 && taxableAmount<=500000) 
				associate.getSalary().setMonthlyTax((taxableAmount-250000/10)/12);
			else if(taxableAmount>500000 && taxableAmount<=1000000)
				associate.getSalary().setMonthlyTax((taxableAmount-500000/5+25000)/12);	 
			else if(taxableAmount>1000000)
				associate.getSalary().setMonthlyTax(((taxableAmount-1000000)*3/10+125000)/12);			
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			associateDAO.update(associate);
			System.out.println(associate.getSalary().getNetSalary());
			return associate.getSalary().getNetSalary(); 

			
			//return associate.getSalary().getNetSalary();
		}
		/*
		@Override
		public List<Associate> getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException {
			Associate associate=associateDAO.findOne(associateID);
			if(associate==null)throw new AssociateDetailsNotFoundException("AssociateID details not found!"+associateID);
			return associate;
		}
		@Override
		public Associate List getAllAssociatesDetails() {
			return PayrollUnit.associates;
		}
		 */
		/*
		List<String> keyList = new ArrayList<String>(companyDetails.keySet());
		System.out.println("\n==> Size of Key list: " + keyList.size());

		for (String temp : keyList) {
			System.out.println(temp);
		}

		// Converting HashMap Values into ArrayList
		List<Integer> valueList = new ArrayList<Integer>(companyDetails.values());
		System.out.println("\n==> Size of Value list: " + valueList.size());
		for (Integer temp : valueList) {
			System.out.println(temp);
		}
		List<Entry> entryList = new ArrayList<Entry>(companyDetails.entrySet());
		System.out.println("\n==> Size of Entry list: " + entryList.size());
		for (Entry temp : entryList) {
			System.out.println(temp);
		 */
		@Override
		public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException {
			Associate associate=associateDAO.findOne(associateID);
			if(associate==null)throw new AssociateDetailsNotFoundException("AssociateID details not found!"+associateID);
			return associate;
		}
		@Override
		public List<Associate> getAllAssociatesDetails() {
			List<Associate> listOfassociates=associateDAO.findAll();   
			return listOfassociates;
			//return (List<Associate>) PayrollUnit.associates.values();
		}
		@Override
		public String deleteAssociate(int associateID) throws AssociateDetailsNotFoundException {
			Associate associate=associateDAO.findOne(associateID);
			  if(associate==null) throw new AssociateDetailsNotFoundException("Mentioned  ID is not FOUND!!!!");
	      associateDAO.delete(associate.getAssociateID());
	     	return "Inputed record has been DELETED!!";
		}
	}

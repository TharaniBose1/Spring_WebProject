package com.cg.payroll.servlets;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/controller1")
public class AcceptDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
    public AcceptDetailsServlet() {
        super();   }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("action").equals("acceptDetails")) {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailID=request.getParameter("emailID");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String panNumber=request.getParameter("panNumber");
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPF=Integer.parseInt(request.getParameter("companypf"));
		String bankName=request.getParameter("bankName");
		int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
		String ifscCode=request.getParameter("ifscCode");
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, panNumber, emailID, 
				new Salary(basicSalary, epf, companyPF),new BankDetails(accountNumber, bankName, ifscCode));
		RequestDispatcher dispatcher=null;
		try {
			int associateID=payrollServices.acceptAssociateDetails(associate);
			dispatcher=request.getRequestDispatcher("registerSuccessPage.jsp");
			 request.setAttribute("associate", associate);
			 dispatcher.forward(request, response);		
		} catch (InvalidEmailException | AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}}
	}}



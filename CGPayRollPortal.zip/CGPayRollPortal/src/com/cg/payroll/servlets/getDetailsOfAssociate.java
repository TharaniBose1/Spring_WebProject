package com.cg.payroll.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/controller3")
public class getDetailsOfAssociate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
    public getDetailsOfAssociate() {
        super();   
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateID2=Integer.parseInt(request.getParameter("associateID"));
		RequestDispatcher dispatcher=null;
		try {
		      Associate associate= payrollServices.getAssociateDetails(associateID2);
				request.setAttribute("associate", associate);
			dispatcher=request.getRequestDispatcher("associateDetailSuccessPage.jsp");
			dispatcher.forward(request, response);}
		catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}	
	}

}

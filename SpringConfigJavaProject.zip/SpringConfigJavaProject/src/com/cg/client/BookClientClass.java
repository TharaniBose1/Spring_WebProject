package com.cg.client;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.cg.bean.Book;
import com.cg.bean.MyBookConfig;
public class BookClientClass {
	public static void main(String[] args) throws Exception {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(MyBookConfig.class);
		Book bookObject=(Book) context.getBean("book");
		System.out.println(" Book HashCode :"+bookObject.hashCode());
		System.out.println("Book Info :"+bookObject);
		try {bookObject.cleanUp();}
catch(Exception e) {e.printStackTrace();}
		context.close();
	}}

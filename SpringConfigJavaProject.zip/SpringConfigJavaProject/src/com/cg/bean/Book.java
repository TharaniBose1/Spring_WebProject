package com.cg.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Book {
private Author author;
private String isbn;
private String year;
public Book() {}
@PostConstruct
public void customBookInit() {
	System.out.println("Metho customBookInit() invoked....................");}
@PreDestroy
public void customBookDestroy() {
	System.out.println("Method customBookDestroy() is invoked...........");}
public void setUp()throws Exception{
	System.out.println("Initializing the Book Bean with customBookInit()");}
public void cleanUp()throws Exception{
	System.out.println("Destroying the Book Bean with customBookDestroy()");}
@Override
public String toString() {
	return "Book [author=" + author + ", isbn=" + isbn + ", year=" + year + "]";
}
public Author getAuthor() {
	return author;
}
public void setAuthor(Author author) {
	this.author = author;
}
public String getIsbn() {
	return isbn;
}
public void setIsbn(String isbn) {
	this.isbn = isbn;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
}

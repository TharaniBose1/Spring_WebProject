package com.cg.banking.util;
import java.util.HashMap;
import java.util.Map;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class BankingApplicationUtil {
	public static Map<Long,Account> accountEntry=new HashMap<>();
	public static Map<Integer,Transaction> transcationEntry=new HashMap<>();
	public static long PICKEDACCOUNTNO=112451200;
	public static long getPICKEDACCOUNTNO() {
		return ++PICKEDACCOUNTNO;}
	public static int TRANSACTIONID=0;
	public static int getTRANSACTIONID() {
		return ++TRANSACTIONID;
	}
	
}

package com.cg.banking.tests;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingApplicationUtil;
import com.itextpdf.text.DocumentException;
public class BankingServiceTest {
private static BankingServices bankingServices;
	private int accountNumber;
	@BeforeClass
	public static void setUpEnv() {
	 bankingServices=new BankingServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1=new Account(112451201, 4512, "Salary", "Active", 45140);
		Account account2=new Account(112451202,1245,"Salary","Active",54210);
		Account account3=new Account(112451203,8745,"Current","Blocked",4210);
		BankingApplicationUtil.accountEntry.put(account1.getAccountNo(),account1);
		BankingApplicationUtil.accountEntry.put(account2.getAccountNo(),account2);
		BankingApplicationUtil.accountEntry.put(account3.getAccountNo(),account3);
		BankingApplicationUtil.PICKEDACCOUNTNO=112451203;}
	@Test(expected=InvalidAccountTypeException.class)
	public void openAccountForInValidAccountType() throws InvalidAmountException, InvalidAccountTypeException,BankingServicesDownException {
   bankingServices.openAccount("Saving", 600);
	}
	@Test(expected=InvalidAmountException.class)
	public void openAccountForInValidInitialBalance() throws InvalidAmountException, InvalidAccountTypeException,BankingServicesDownException {
   bankingServices.openAccount("Savings", 100);
	}
	@Test
	public void openAccountForValidAccountNo() throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account actualAccount=bankingServices.openAccount("Savings", 1000);
		long expectedAccountNo=112451204;
		assertEquals(expectedAccountNo, actualAccount.getAccountNo());
	}
	@Test(expected=AccountNotFoundException.class)
	public void depositInvalidAccountNo() throws FileNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, IOException, DocumentException {
		bankingServices.depositAmount(11245132,860);
	}
	@Test
	public void depositForValidAcccountNo() throws FileNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, IOException, DocumentException {
		float actualBalance=bankingServices.depositAmount(112451201, 1000);
		float expectedBalance=45140;
		assertEquals(expectedBalance,actualBalance,1000);
	}
	@Test(expected=AccountNotFoundException.class)
	public void depositForInvalidAccountNo() throws FileNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, IOException, DocumentException {
		bankingServices.depositAmount(1121512011, 1000);
	}
	
@After
public void tearDownData() {
	BankingApplicationUtil.accountEntry.clear();
	BankingApplicationUtil.PICKEDACCOUNTNO=112451200;
}
@AfterClass
public static void setDownEnv() {
	bankingServices=null;
}
}

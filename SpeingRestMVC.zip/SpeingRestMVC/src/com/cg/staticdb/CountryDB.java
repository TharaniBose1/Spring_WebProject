package com.cg.staticdb;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Country;
public class CountryDB {
private static ArrayList<Country> countryList=new ArrayList<>();
static {
	countryList.add(new Country("1001", "India", "12451201"));
	countryList.add(new Country("1002", "Canada", "51201"));
	countryList.add(new Country("1003", "Pakistan", "65451"));
	countryList.add(new Country("1004", "Sri Lanka", "51201"));
	countryList.add(new Country("1005", "Denmark", "2015124"));
}
public static ArrayList<Country> getCountryList(){
	return countryList;
}
public static void setCountryList(List<Country>countryList) {
CountryDB.countryList=(ArrayList<Country>) countryList;	
}
}

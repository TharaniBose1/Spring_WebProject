package com.cg.ctrl;
import java.util.List;

import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.cg.bean.Country;
import com.cg.service.ICountryService;
@RestController
public class CountryController {
	@Autowired
ICountryService iCountryService=null;
	public ICountryService getiCountryService() {
		return iCountryService;}
	public void setiCountryService(ICountryService iCountryService) {
		this.iCountryService = iCountryService;}
	@RequestMapping(value="/countries/search/{id}",method=RequestMethod.GET,headers="Accept=application/json")
	public Country getCountry(@PathVariable int id) {
		return iCountryService.searchCountry(id);}

	@RequestMapping(value="/countries",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Country> getAllCountries(Model model){
		return iCountryService.getAllCountries();}
	
	
	@RequestMapping( value="/countries/create/{id}/{name}/{popu}",headers="Accept=application/json",method=RequestMethod.POST)
public List<Country> createCountry(@PathVariable String id,@PathVariable String name,@PathVariable String popu,ModelAndView model){
	Country country=new Country();
	country.setCountryId(id);
	country.setCountryName(name);
	country.setPopulation(popu);
	iCountryService.addCountry(country);
	return iCountryService.getAllCountries();}
	
	
	@RequestMapping(value="/countries/delete/{id}",headers="Accept=application/json",method=RequestMethod.DELETE)
	public List<Country> deleteCountry(@PathVariable int id){
		iCountryService.deleteCountry(id);
		return iCountryService.getAllCountries();
	}
}

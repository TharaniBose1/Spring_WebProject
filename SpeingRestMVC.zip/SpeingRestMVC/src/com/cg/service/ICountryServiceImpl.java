package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Country;
import com.cg.dao.ICountryDAO;
@Service
public class ICountryServiceImpl implements ICountryService{
@Autowired
ICountryDAO iCountryDAO=null;
/*	public ICountryDAO getiCountryDAO() {
	return iCountryDAO;
}
public void setiCountryDAO(ICountryDAO iCountryDAO) {
	this.iCountryDAO = iCountryDAO;
}*/
	@Override
	public List<Country> getAllCountries() {
		return iCountryDAO.getAllCountries();}
	@Override
	public void addCountry(Country country) {
		iCountryDAO.addCountry(country);}
	@Override
	public Country deleteCountry(int id) {
		return iCountryDAO.deleteCountry(id);}
	@Override
	public Country searchCountry(int id) {
		return iCountryDAO.searchCountry(id);}}

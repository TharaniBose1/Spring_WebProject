package com.cg.dao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cg.bean.Country;
import com.cg.staticdb.CountryDB;
@Repository
public class ICountryDAOImpl implements ICountryDAO{
	@Override
	public List<Country> getAllCountries() {
		
		return CountryDB.getCountryList();}
	@Override
	public void addCountry(Country country) {
		CountryDB.getCountryList().add(country);}
	@Override
	public Country deleteCountry(int id) {
		return CountryDB.getCountryList().remove(id);}
	@Override
	public Country searchCountry(int id) {
		return CountryDB.getCountryList()
				.stream()
				.filter(c->Integer.parseInt(c.getCountryId())==id)
				.findFirst()
				.get();}}

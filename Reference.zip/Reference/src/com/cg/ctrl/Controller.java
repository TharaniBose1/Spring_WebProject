package com.cg.ctrl;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
public class Controller {
	@RequestMapping(value="/GenerateCouponID",method=RequestMethod.GET)
	public String  GenerateID(Model model) {	
		return "acceptpancard";}
}

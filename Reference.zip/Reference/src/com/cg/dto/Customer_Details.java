package com.cg.dto;
public class Customer_Details {

}

package com.cg.beans;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployeeMain {
	public static void main(String[] args) {
	ApplicationContext context=new 	ClassPathXmlApplicationContext("assignmentcg.xml");
	/*Employee1 employee1=(Employee1) context.getBean("employeeObject1");
	System.out.println(employee1);*/
	/*SBU2 sbu2=(SBU2) context.getBean("sbuObject2");
	System.out.println(sbu2);*/
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter ID:");
	Employee1 employee1=(Employee1) context.getBean("employeeObject1");
	if(employee1.getEmpId()==scan.nextInt())
		System.out.println(employee1);
	else System.out.println("Entered wrong Employee Id");
	}

}

package com.cg.beans;
import java.util.ArrayList;
public class SBU2 {
private int sbuCode;
private String sbuName,sbuHead;
private ArrayList<Employee2> empList;
public int getSbuCode() {
	return sbuCode;
}
public void setSbuCode(int sbuCode) {
	this.sbuCode = sbuCode;
}
public String getSbuName() {
	return sbuName;
}
public void setSbuName(String sbuName) {
	this.sbuName = sbuName;
}
public String getSbuHead() {
	return sbuHead;
}
public void setSbuHead(String sbuHead) {
	this.sbuHead = sbuHead;
}
public ArrayList<Employee2> getEmpList() {
	return empList;
}
public void setEmpList(ArrayList<Employee2> empList) {
	this.empList = empList;
}
@Override
public String toString() {
	return "SBU2 [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", empList=" + empList + "]";
}
}

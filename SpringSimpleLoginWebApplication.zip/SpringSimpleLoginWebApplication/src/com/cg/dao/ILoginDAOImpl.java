 package com.cg.dao;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;
@Repository("loginDAO")
@Transactional
public class ILoginDAOImpl implements ILoginDAO{
	@PersistenceContext
	EntityManager entityManger=null;
	public EntityManager getEntityManger() {
		return entityManger;
	}
	public void setEntityManger(EntityManager entityManger) {
		this.entityManger = entityManger;
	}
	@Override
	public boolean isUserExist(String userName) {
		Login user=entityManger.find(Login.class,userName);
		if(user!=null)return true;
		return false;}
	@Override
	public Login validateUser(Login login) {	
		Login user=entityManger.find(Login.class,login.getUserName());
		return user;}
	@Override
	public RegisterDTO insertUserDetails(RegisterDTO userDetails) {
		Login loginObject=new Login();
		loginObject.setUserName(userDetails.getUserName());
		loginObject.setPassword(userDetails.getPassWord()); 
			/*StringBuffer str=new StringBuffer();
			for (String tempStr:userDetails.getSkillSet() )
				str.append(tempStr+",");
				//str+=tempStr+",";			
			userDetails.setSkillSetStr(str.toString());*/
		System.out.println("Hey username :"+loginObject.getUserName());
		System.out.println("Hey Password :"+loginObject.getPassword());
		entityManger.persist(loginObject);
		entityManger.persist(userDetails);
		entityManger.flush();
		RegisterDTO registeredUser=entityManger.find(RegisterDTO.class, userDetails.getUserName());
		return  registeredUser;
	}
	@Override
	public ArrayList<RegisterDTO> getAllUserDetails() {
		String query="Select register From RegisterDTO register";
		TypedQuery typedQuery=entityManger.createQuery(query, RegisterDTO.class);
		ArrayList<RegisterDTO> updatedList=(ArrayList<RegisterDTO>) typedQuery.getResultList();
		return updatedList;
	}
	@Override
	public boolean deleteUser(String userName) {
	RegisterDTO registerDTOFlag=entityManger.find(RegisterDTO.class,userName);
	Login loginFlag=entityManger.find(Login.class,userName);
	entityManger.remove(registerDTOFlag);
	entityManger.remove(loginFlag);
	entityManger.flush();
		return true;
	}	
}

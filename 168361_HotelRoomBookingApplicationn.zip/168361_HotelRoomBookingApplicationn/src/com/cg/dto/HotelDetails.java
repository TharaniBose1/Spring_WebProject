package com.cg.dto;

public class HotelDetails {
private int ID;
private String hotelName;
private int rating;
private int rate;
private int availableRooms;
public HotelDetails() {}
public int getID() {
	return ID;
}
public void setID(int iD) {
	ID = iD;
}
public String getHotelName() {
	return hotelName;
}
public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public int getAvailableRooms() {
	return availableRooms;
}
public void setAvailableRooms(int availableRooms) {
	this.availableRooms = availableRooms;
}

}
